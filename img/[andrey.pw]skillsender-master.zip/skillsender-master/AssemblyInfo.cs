﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Skill Sender")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Skill Sender")]
[assembly: AssemblyCopyright("Copyright ©  2XXX")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("207ec937-6f11-42f8-b9a4-eca1616e32b8")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
