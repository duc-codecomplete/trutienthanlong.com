namespace Enhance
{
  public class TriggerEventArgs
  {
    public int Msg;

    public TriggerEventArgs(int msg)
    {
      this.Msg = msg;
    }
  }
}
