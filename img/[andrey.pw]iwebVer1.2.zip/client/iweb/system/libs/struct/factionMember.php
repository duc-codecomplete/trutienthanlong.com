<?php

namespace system\libs\struct;

if (!defined('IWEB')) {die("Error!");}

class factionMember{
    public $rid;
    public $role;

}